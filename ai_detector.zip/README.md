# AI Detector + Humanizer (English & Kiswahili)

## Run
```bash
pip install -r requirements.txt
python app.py        # open http://127.0.0.1:5000
```
For stronger detection install `torch` and `transformers` (GPT-2 perplexity, English only).
First run downloads the model (~500 MB).

## Files
- `detector.py`  - signals: perplexity (optional), burstiness, AI stock phrases, transition density,
  contractions, opener diversity, repetition, vocab richness, informality + per-sentence scores.
- `humanizer.py` - style editor: phrase swaps, contractions, split/merge sentences, trim transitions
  (levels: light / medium / strong).
- `app.py`       - Flask UI + API (`POST /api/detect`, `POST /api/humanize`).

## Use from Python
```python
from detector import analyze
from humanizer import humanize
print(analyze(text)["ai_probability"])
new_text, meta = humanize(text, level="medium")
```

## Limits (be honest with yourself)
- Heuristic detector: false positives and false negatives are normal, especially for non-native
  English writers and for short or formal text.
- Humanizer improves *style*; it does not change meaning. Always read and edit the result,
  and follow your school's rules on AI use.

## Improve it
Train a classifier (e.g. logistic regression / DistilBERT) on a labelled human-vs-AI dataset and
add its probability as another signal in `detector.WEIGHTS`. A Swahili dataset would make the
Kiswahili side far stronger.
